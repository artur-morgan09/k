package main

import (
	"fmt"
	"runtime"
	"time"
)

type StudentID int64

const (
	TotalCourses = 4
	ExcellentGPA = 4.5
)

func main() {
	var studentID StudentID = 1001
	studentName := "Иван Петров"
	birthYear := 2006
	currentCourse := 2
	averageGrade := 4.75
	isActive := true
	currentYear := time.Now().Year()

	age := currentYear - birthYear
	completedCourses := currentCourse - 1
	remainingCourses := TotalCourses - currentCourse
	graduationYear := currentYear + remainingCourses
	isExcellent := averageGrade >= ExcellentGPA

	fmt.Println("================================")
	fmt.Println("ПРОФИЛЬ СТУДЕНТА")
	fmt.Println("================================")
	fmt.Printf("ID: %d\n", studentID)
	fmt.Printf("Имя: %s\n", studentName)
	fmt.Printf("Возраст: %d\n", age)
	fmt.Printf("Курс: %d из %d\n", currentCourse, TotalCourses)
	fmt.Printf("Завершено курсов: %d\n", completedCourses)
	fmt.Printf("Осталось курсов: %d\n", remainingCourses)
	fmt.Printf("Год выпуска: %d\n", graduationYear)
	fmt.Printf("Средний балл: %.2f\n", averageGrade)
	fmt.Printf("Отличник: %t\n", isExcellent)
	fmt.Printf("Активен: %t\n", isActive)
	fmt.Printf("Платформа: %s\n", runtime.GOOS)
	fmt.Println("================================")
}
