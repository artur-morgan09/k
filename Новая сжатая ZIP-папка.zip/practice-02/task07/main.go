package main

import "fmt"

type StudentID int64
type CourseID int64

func main() {
	var studentID StudentID = 1001
	var courseID CourseID = 25

	fmt.Printf("Student ID: %d\n", studentID)
	fmt.Printf("Course ID: %d\n", courseID)

	// studentID = courseID
	// Компилятор не разрешит присвоить CourseID переменной StudentID
	// без явного преобразования. Разные типы помогают не перепутать,
	// например, идентификатор студента с идентификатором курса.
}
