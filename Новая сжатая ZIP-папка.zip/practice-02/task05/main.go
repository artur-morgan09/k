package main

import "fmt"

type Celsius float64

func main() {
	var temperatureCelsius Celsius = 25.0
	temperatureFahrenheit := float64(temperatureCelsius)*9/5 + 32
	temperatureKelvin := float64(temperatureCelsius) + 273.15

	fmt.Printf("Температура по Цельсию: %.2f °C\n", temperatureCelsius)
	fmt.Printf("Температура по Фаренгейту: %.2f °F\n", temperatureFahrenheit)
	fmt.Printf("Температура по Кельвину: %.2f K\n", temperatureKelvin)
}
