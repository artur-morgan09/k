запускал: 
package main

import "fmt"

func main() {

	fmt.Println("Студент: Анна Петрова")
	fmt.Println("Группа: ИВТ-21")
	fmt.Println("Платформа: macOS")
	fmt.Println("Учебный год: 2026-2027")
	fmt.Println("Практическая работа: 1")

вышло: 
# command-line-arguments
.\main.go:14:1: syntax error: unexpected EOF, expected }

запускал: 
package main

import "strings"

func main() {

	fmt.Println("Студент: Анна Петрова")
	fmt.Println("Группа: ИВТ-21")
	fmt.Println("Платформа: macOS")
	fmt.Println("Учебный год: 2026-2027")
	fmt.Println("Практическая работа: 1")


}

вышло:
Студент: Анна Петрова
Группа: ИВТ-21
Платформа: macOS
Учебный год: 2026-2027
Практическая работа: 1

запускал:
package main

import "fmt"

func start() {

	fmt.Println("Студент: Анна Петрова")
	fmt.Println("Группа: ИВТ-21")
	fmt.Println("Платформа: macOS")
	fmt.Println("Учебный год: 2026-2027")
	fmt.Println("Практическая работа: 1")


}
вышло:
Студент: Анна Петрова
Группа: ИВТ-21
Платформа: macOS
Учебный год: 2026-2027
Практическая работа: 1