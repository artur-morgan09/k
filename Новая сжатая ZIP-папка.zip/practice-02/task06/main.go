package main

import (
	"fmt"
	"strconv"
)

func main() {
	input := "2026"
	year, err := strconv.Atoi(input)
	if err != nil {
		fmt.Printf("Ошибка преобразования %q: %v\n", input, err)
		return
	}
	fmt.Printf("Число: %d\n", year)

	input = "20x6"
	year, err = strconv.Atoi(input)
	if err != nil {
		fmt.Printf("Ошибка преобразования %q: %v\n", input, err)
		return
	}
	fmt.Printf("Число: %d\n", year)
}
