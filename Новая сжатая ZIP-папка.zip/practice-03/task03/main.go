package main

import "fmt"

func main() {
	age := 20

	if age < 0 {
		fmt.Println("ошибка")
		return
	}

	if age <= 6 {
		fmt.Println("дошкольник")
	} else if age <= 17 {
		fmt.Println("школьник")
	} else if age <= 24 {
		fmt.Println("студент или молодой специалист")
	} else if age <= 64 {
		fmt.Println("взрослый")
	} else {
		fmt.Println("пенсионный возраст")
	}
}
