package main

import "fmt"

const (
	TotalCourses = 4
	MonthsInYear = 12
	ExcellentGPA = 4.5
)

func main() {
	monthsOfStudy := TotalCourses * MonthsInYear
	studentGPA := 4.7
	isExcellent := studentGPA >= ExcellentGPA
	completedCourses := 2
	coursesLeft := TotalCourses - completedCourses

	fmt.Printf("Месяцев обучения: %d\n", monthsOfStudy)
	fmt.Printf("Средний балл: %.2f\n", studentGPA)
	fmt.Printf("Отличник: %t\n", isExcellent)
	fmt.Printf("Осталось курсов до выпуска: %d\n", coursesLeft)

	// TotalCourses = 5
	// Компилятор выдаст ошибку, потому что константу нельзя изменить
	// после объявления.
}
