package main

import "fmt"

func main() {

	name := "Анна Петрова"
	group := "ИВТ-21"
	osName := "Windows"
	year := "2026-2027"
	work := "1"
	lang := "Go"

	fmt.Println("Имя:", name)
	fmt.Println("Группа:", group)
	fmt.Println("Операционная система:", osName)
	fmt.Println("Язык:", lang)
	fmt.Println()

	line := "================================"

	fmt.Println(line)
	fmt.Println("       ЯЗЫК ПРОГРАММИРОВАНИЯ GO")
	fmt.Println(line)
	fmt.Println("Студент:", name)
	fmt.Println("Группа:", group)
	fmt.Println("Платформа:", osName)
	fmt.Println("Учебный год:", year)
	fmt.Println("Практическая работа:", work)
	fmt.Println(line)
	fmt.Println("Среда готова к работе")
}
