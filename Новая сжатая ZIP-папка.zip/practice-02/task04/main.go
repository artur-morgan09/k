package main

import "fmt"

func main() {
	total := 17
	count := 5

	fmt.Printf("Целая часть: %d\n", total/count)
	fmt.Printf("Остаток: %d\n", total%count)

	average := float64(total) / float64(count)
	fmt.Printf("Среднее: %.2f\n", average)
}
