package main

import "fmt"

func main() {
	priorities := []int{1, 3, 2, 5, 0, 4, 8, -1}

	lowCount := 0
	normalCount := 0
	highCount := 0
	criticalCount := 0
	validCount := 0
	invalidCount := 0
	sum := 0

	for index, priority := range priorities {
		if priority < 1 || priority > 5 {
			fmt.Printf("Задача %d: некорректный приоритет %d\n", index+1, priority)
			invalidCount++
			continue
		}

		var category string
		switch priority {
		case 1:
			category = "низкий"
			lowCount++
		case 2, 3:
			category = "обычный"
			normalCount++
		case 4:
			category = "высокий"
			highCount++
		case 5:
			category = "критический"
			criticalCount++
		}

		fmt.Printf("Задача %d: приоритет %d — %s\n", index+1, priority, category)
		validCount++
		sum += priority
	}

	fmt.Println("\nИТОГИ")
	fmt.Printf("Корректных задач: %d\n", validCount)
	fmt.Printf("Некорректных значений: %d\n", invalidCount)
	fmt.Printf("Низкий приоритет: %d\n", lowCount)
	fmt.Printf("Обычный приоритет: %d\n", normalCount)
	fmt.Printf("Высокий приоритет: %d\n", highCount)
	fmt.Printf("Критический приоритет: %d\n", criticalCount)

	if validCount == 0 {
		fmt.Println("Средний приоритет: нет данных для вычисления")
		return
	}

	average := float64(sum) / float64(validCount)
	fmt.Printf("Средний приоритет: %.2f\n", average)
}
