package main

import "fmt"

func main() {
	var number int
	var average float64
	var active bool
	var name string

	fmt.Printf("int: [%v]\n", number)
	fmt.Printf("float64: [%v]\n", average)
	fmt.Printf("bool: [%v]\n", active)
	fmt.Printf("string: [%v]\n", name)

	// Zero value — значение, которое Go автоматически присваивает переменной,
	// если начальное значение не указано. Поэтому у переменной всегда есть
	// значение соответствующего типа, а не неопределённое содержимое.
}
