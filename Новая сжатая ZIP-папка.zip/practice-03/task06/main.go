package main

import "fmt"

func main() {
	score := 87

	switch {
	case score < 0 || score > 100:
		fmt.Println("некорректный балл")
	case score >= 90:
		fmt.Println("отлично")
	case score >= 75:
		fmt.Println("хорошо")
	case score >= 60:
		fmt.Println("удовлетворительно")
	default:
		fmt.Println("не зачтено")
	}
}
