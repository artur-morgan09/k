package main

import "fmt"

func main() {
	// Объявления переменных тремя способами.
	var studentName string = "Иван Петров"
	var age = 19
	averageGrade := 4.3
	hasScholarship := true

	fmt.Printf("studentName: %T = %v\n", studentName, studentName)
	fmt.Printf("age: %T = %v\n", age, age)
	fmt.Printf("averageGrade: %T = %v\n", averageGrade, averageGrade)
	fmt.Printf("hasScholarship: %T = %v\n", hasScholarship, hasScholarship)
}
