package main

import "fmt"

func main() {
	number := -7

	if number > 0 {
		fmt.Println("положительное")
	} else if number < 0 {
		fmt.Println("отрицательное")
	} else {
		fmt.Println("ноль")
	}
}
