package main

import "fmt"

func main() {
	command := "list"

	switch command {
	case "add":
		fmt.Println("Добавление задачи")
	case "list":
		fmt.Println("Список задач")
	case "done":
		fmt.Println("Завершение задачи")
	case "exit", "quit":
		fmt.Println("Выход")
	default:
		fmt.Println("Неизвестная команда")
	}
}
