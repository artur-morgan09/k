package main

import "fmt"

func main() {
	fmt.Println("Классический for:")
	for i := 1; i <= 10; i++ {
		fmt.Printf("7 × %d = %d\n", i, 7*i)
	}

	fmt.Println("\nfor i := range 10:")
	for i := range 10 {
		fmt.Printf("7 × %d = %d\n", i+1, 7*(i+1))
	}
}
