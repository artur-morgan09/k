package main

import "fmt"

func main() {
	scores := []int{95, 82, 74, 61, 48, 103, -5}

	sum := 0
	count := 0
	minimum := 0
	maximum := 0

	for _, score := range scores {
		if score < 0 || score > 100 {
			continue
		}

		if count == 0 {
			minimum = score
			maximum = score
		} else {
			if score < minimum {
				minimum = score
			}
			if score > maximum {
				maximum = score
			}
		}

		sum += score
		count++
	}

	if count == 0 {
		fmt.Println("Нет корректных результатов")
		return
	}

	average := float64(sum) / float64(count)
	fmt.Printf("Корректных результатов: %d\n", count)
	fmt.Printf("Сумма: %d\n", sum)
	fmt.Printf("Минимум: %d\n", minimum)
	fmt.Printf("Максимум: %d\n", maximum)
	fmt.Printf("Среднее: %.2f\n", average)
}
