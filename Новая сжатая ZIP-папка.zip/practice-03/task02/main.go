package main

import "fmt"

func main() {
	n := 12

	isEven := n%2 == 0
	isDivisibleByThree := n%3 == 0
	isDivisibleByTwoAndThree := isEven && isDivisibleByThree

	fmt.Printf("Чётное: %t\n", isEven)
	fmt.Printf("Делится на 3: %t\n", isDivisibleByThree)
	fmt.Printf("Делится на 2 и 3: %t\n", isDivisibleByTwoAndThree)
}
