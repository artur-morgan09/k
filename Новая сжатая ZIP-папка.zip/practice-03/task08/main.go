package main

import "fmt"

func main() {
	text := "Go, мир!"

	for index, symbol := range text {
		fmt.Printf("Индекс: %d, символ: %c, Unicode: %U\n", index, symbol, symbol)
	}

	// В UTF-8 кириллические буквы занимают по два байта,
	// поэтому байтовые индексы после них увеличиваются не на единицу.
}
