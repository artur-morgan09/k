package main

import "fmt"

type TaskStatus int

const (
	StatusUnknown TaskStatus = iota
	StatusNew
	StatusInProgress
	StatusDone
)

func main() {
	fmt.Printf("StatusUnknown: %d\n", StatusUnknown)
	fmt.Printf("StatusNew: %d\n", StatusNew)
	fmt.Printf("StatusInProgress: %d\n", StatusInProgress)
	fmt.Printf("StatusDone: %d\n", StatusDone)
}
