module example.com/practice-02

go 1.22
